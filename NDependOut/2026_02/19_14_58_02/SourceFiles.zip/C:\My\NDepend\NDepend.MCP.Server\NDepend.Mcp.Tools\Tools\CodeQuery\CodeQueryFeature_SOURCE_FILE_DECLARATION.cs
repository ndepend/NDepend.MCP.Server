namespace NDepend.Mcp.Tools.CodeQuery;
internal partial class CodeQueryFeature {
    internal const string SOURCE_FILE_DECLARATION_PROMPT =
          """
          # CODE ELEMENT SOURCE FILE DECLARATIONS
          
          ## Overview
          Code elements in this API expose source file location information through the `ICodeElement` interface. This guide explains how to access and work with source file declarations.
          
          ## Key Concepts
          
          ### Multiple Declarations
          A code element can have **zero, one, or multiple** source declarations:
          - **Partial classes**: Multiple declarations across different files
          - **Namespaces**: Can span multiple files
          - **Regular classes**: Typically one declaration
          - **External/compiled types**: May have zero declarations
          
          ## API Reference
          
          ### ICodeElement Properties
          ```csharp
          IEnumerable<ISourceDecl> SourceDecls { get; }
          bool SourceFileDeclAvailable { get; }
          ```
          
          **IMPORTANT**: Always check `SourceFileDeclAvailable` before accessing `SourceDecls` to avoid runtime errors.
                 
          ### ISourceDecl Properties
          ```csharp
          ISourceFile SourceFile { get; }    // The source file containing this declaration
          uint Line { get; }                 // 1-based line number
          uint Column { get; }               // 1-based column number
          ```
          
          ### ISourceFile Properties
          
          **File Identification:**
          - `IAbsoluteFilePath FilePath` � Absolute file path object
          - `string FilePathString` � Path as string
          - `string FileName` � File name with extension (e.g., "Program.cs")
          - `string FileNameWithoutExtension` � File name only (e.g., "Program")
          - `SourceFileLanguage Language` � CSharp, VBNet, FSharp, or Other
          
          **Code Metrics:**
          - `IEnumerable<ICodeElement> CodeElements` � All code elements declared in this file
          - `uint NbLines` � Total physical lines
          - `uint NbCharacters` � Total characters
          - `uint? NbLinesOfCode` � Lines of code (nullable)
          - `uint NbLinesOfComment` � Lines containing comments
          - `uint? NbILInstructions` � Compiled IL instructions (nullable)
          
          **Code Coverage:**
          - `bool CoverageDataAvailable` � True if coverage data exists
          - `float? PercentageCoverage` � Coverage percentage (0-100, nullable)
          - `uint? NbLinesOfCodeCovered` � Covered lines count (nullable)
          - `uint? NbLinesOfCodeNotCovered` � Uncovered lines count (nullable)
          
          ## Common Patterns
          
          ### Pattern 1: Safe Access to Source Declarations
          ```csharp
          from m in Application.Methods
          where m.SourceFileDeclAvailable
          let sourceDecl = m.SourceDecls.FirstOrDefault()
          where sourceDecl != null
          select new { m, sourceDecl.SourceFile }
          ```
          
          ### Pattern 2: Handling Single Declaration
          ```csharp
          from t in Application.Types
          where t.SourceFileDeclAvailable && t.SourceDecls.Count() == 1
          let decl = t.SourceDecls.Single()
          select new { t, decl.SourceFile.FilePathString, decl.Line }
          ```
          
          ### Pattern 3: Handling Multiple Declarations
          ```csharp
          from t in Application.Types.Where(t => t.SourceFileDeclAvailable)
          from decl in t.SourceDecls
          select new { Type = t, File = decl.SourceFile.FileName, decl.Line }
          ```
          
          ## Examples
          
          ### Example 1: Filter by Directory Path
          ```csharp
          // <Name>Methods whose source is declared in a directory named Customer</Name>
          from m in Application.Methods
          where m.SourceFileDeclAvailable
          let parentDir = m.SourceDecls.Single().SourceFile.FilePath.ParentDirectoryPath.ToString()
          where parentDir.ContainsAny(@"\Customer\", @"/Customer/", StringComparison.OrdinalIgnoreCase)
          select m
          ```
          
          ### Example 2: Files with Multiple Type Declarations
          ```csharp
          // <Name>List types whose source file contains other types</Name>
          
          // Group types by their source file path, considering only types with a single declaration
          let  groups = Application.Types
              .Where(t => t.SourceFileDeclAvailable && t.SourceDecls.Count() == 1)
              .ToLookup(t => t.SourceDecls.Single().SourceFile.FilePathString, StringComparer.OrdinalIgnoreCase)
          
          // Flatten the groups and select types along with their source file path, ordered by file path
          from t in groups.SelectMany(g => g)
          let filePath = t.SourceDecls.Single().SourceFile.FilePathString
          orderby filePath
          select new { t, filePath }
          ```
          """;
}
