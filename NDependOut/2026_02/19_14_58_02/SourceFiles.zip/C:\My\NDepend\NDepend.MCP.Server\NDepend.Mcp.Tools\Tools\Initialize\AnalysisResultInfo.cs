namespace NDepend.Mcp.Tools.Initialize;

[Description("Current and baseline analysis info")]
public record AnalysisResultInfo(
    [property: Description("Current analysis date")]
    DateTime ResultDate,
    [property: Description("Current project name")]
    string ResultProjectName,
    [property: Description("Current project file path")]
    string ResultProjectFilePath,
    [property: Description("Baseline analysis date")]
    DateTime BaselineResultDate
);
